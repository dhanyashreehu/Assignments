package rectangle4;
import java.util.Scanner;
public class Rectangle {
        private double length,width,perimeter,area;
    Rectangle(double len,double wid)
    {
        length=len;
        width=wid;
    }

    public int setLength(double length) {
        if (length > 0.0 && length < 20.00) {
            if ((length % 1 != 0)) {
                this.length = length;
                return 1;
            } else
                System.out.println("lenght is not a floating point number");
        } else {
            System.out.println("lenght is out of range i.e, greater than 20.00");
        }
        return 0;
    }
            public int setWidth(double width) {
        if (width > 0.0 && width < 20.00) {
            if (width % 1 != 0) {
                this.width = width;
                return 1;
            }else
            System.out.println("width is not a floating point number");
        }
        else {
            System.out.println("width is out of range");
                   }
            return 0;
    }
    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }

    Rectangle()
        {
        length=1;
        width=1;
    }


 public void perimeter(double length,double width) {
 perimeter=2*(length+width);
 //return perimeter
    }
    public void area(double length,double width) {
        area = length * width;
    }
        void display() {
            System.out.println("length and width are " +length+" and" +width);
            double roundof=Math.round(perimeter*100)/100;
            System.out.println("perimeter= " +roundof);
            double roundof1=Math.round(area*100)/100;
            System.out.println("area= " +roundof1);
            // System.out.printf("area= %.2D",area);
        }

    }

