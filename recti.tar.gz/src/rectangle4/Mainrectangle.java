package rectangle4;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Mainrectangle {
            public static void main(String[] args) {
                double len=1,wid=1;
            Rectangle rect = new Rectangle(len,wid);
                rect.setLength(len);
                rect.setWidth(wid);
                rect.perimeter(len,wid);
                rect.area(len,wid);
            rect.display();
            Rectangle rect1[] = new Rectangle[5];
            for (int i = 0; i < rect1.length; i++) {
                Scanner in = new Scanner(System.in);
                try {

                    System.out.println("enter length of rectangle");
                    len = in.nextFloat();

                    System.out.println("enter breadth of rectangle");
                    wid = in.nextFloat();
                    if (len > 0 && wid > 0) {
                        rect1[i] = new Rectangle();
                            int res = rect1[i].setLength(len);
                            int res2=rect1[i].setWidth(wid);
                            if(res==1 && res2==1) {
                                rect1[i].perimeter(len, wid);
                                rect1[i].area(len, wid);
                                rect1[i].display();
                            }
                            }
                            else
                        System.out.println("enter positive numbers only");
                }
                catch (InputMismatchException e) {
                    System.out.println(" is not a valid integer number");
                    // double len = in.nextDouble();
                }

            }

        }}

