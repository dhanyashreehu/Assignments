package Emp;

import java.util.Scanner;

public class MainEmployee {


    public static void main(String[] args) {
        int ch;
        SearchEmployee emp[] = new SearchEmployee[5];
        //int a[]=new int[20];
        for (int i = 0; i < 3; i++) {
            emp[i] = new SearchEmployee();
            //a[i]=
                    emp[i].addDetails();
        }

        for (int i = 0; i < 3; i++) {
            System.out.println("select your choice\n2:listing \n3:searching");
            Scanner in = new Scanner(System.in);
            ch = in.nextInt();
            switch (ch) {
                case 2:
                    if (ch == 2) {
                        for (i = 0; i < 3; i++) {
                            //System.out.println("selected listing option");
                            emp[i].list();
                        }
                        break;
                    }
                case 3:
                    if (ch == 3) {
                        for (i = 0; i < 3; i++) {
                            System.out.println("selected search option");
                            System.out.println("enter emp number");
                            Scanner inn = new Scanner(System.in);
                            int eid = inn.nextInt();
                          //  String key=inn.nextLine();
                            int flag=emp[i].search(eid,emp);
                            if(flag!=1)
                                continue;
                            break;
                        }
                    }
                default:
                    System.out.println(" ");
            }
        }
    }
}