package Emp;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Employee {
    private int emp_num;
    private String emp_name;
    private String emp_jdate;
    private Integer[] listOfEmpNum;


    Employee() {
        this.emp_num = 0;
        this.emp_name = "asd";
        this.emp_jdate = "01/01/1000";
    }

    Employee(int num, String name, String jdate) {
        this.emp_num = num;
        this.emp_name = name;
        this.emp_jdate = jdate;
    }

    public int getEmp_num() {
        return emp_num;
    }

    public void setEmp_num(int emp_num) {
        this.emp_num = emp_num;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    public String getEmp_jdate() {
        return emp_jdate;
    }

    public void setEmp_jdate(String emp_jdate) {
        this.emp_jdate = emp_jdate;
    }

   public void store(int emp_num)
   {
       for(int i=0;i<3;i++)
       listOfEmpNum[i]=emp_num;
   }
    public void addDetails() {
        System.out.println("enter employee number");
        Scanner in = new Scanner(System.in);
        emp_num = in.nextInt();
        setEmp_num(emp_num);
      // store(emp_num);

        System.out.println("enter employee name");
        Scanner ins = new Scanner(System.in);
        emp_name = ins.nextLine();
        setEmp_name(emp_name);

        System.out.println("enter employee joining date");
        Scanner inss = new Scanner(System.in);
        //String date = inss.nextLine();

        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        Date testDate = null;
        emp_jdate = inss.nextLine();
        try {
            testDate = df.parse(emp_jdate);
        } catch (ParseException e) {
            System.out.println("invalid format");
            emp_jdate = inss.nextLine();
        }

        setEmp_jdate(emp_jdate);

        //return emp_num;

    }

    void list() {
        System.out.println("employee details are");
        int num = getEmp_num();
        String name = getEmp_name();
        String date = getEmp_jdate();
        System.out.println("emp number=" + num + "\nemp name=" + name + "\nemp joining date=" + date);
    }
}
