package Emp;

public class SearchEmployee extends Employee {

    SearchEmployee()
    {

    }
    public int search(int eid,SearchEmployee[] emp) {
      int empn;
       //empn=new int[3];
        for (int i = 0; i < 3; i++) {
            //empn=emp.getEmp_num();
            //empn = getEmp_num();
            //int empn[5]=getEmp_num();
            // Boolean bool=empn.compareTo(eid);
            //  if(emp_num==eid)
           // System.out.println(emp);
            if (emp[i].getEmp_num() == (eid)) {
                String date = emp[i].getEmp_jdate();
                System.out.println("joining date of employee is " + date);
                String name = emp[i].getEmp_name();
                System.out.println("name of employee is " + name);
                int num = emp[i].getEmp_num();
                System.out.println("number of employee is " + num);
                return 1;
            } else

                continue;
                //System.out.println("enter valid details");
        }
           return 0;
        }

    }
