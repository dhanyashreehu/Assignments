package p2;
import java.util.Scanner;
public class userrect {
   private int l, b,area;
    userrect() {
        System.out.println("in def cons");
        l = 0;
        b = 0;
        rarea(l,b);
    }
    userrect(int len,int bre)
    {
        l=len;
        b=bre;
        System.out.println("in param cons");
        rarea(l,b);
    }
    void rarea(int l, int b) {
        area = l * b;

    }
    void disp() {
        System.out.println("length and breadth are " + l+" " + b);
        System.out.println("area= " + area);
    }

}