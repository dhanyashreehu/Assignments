import java.util.Scanner;

public class Date1 {

}
