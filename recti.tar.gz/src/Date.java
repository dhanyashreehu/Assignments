import java.text.ParseException;
import java.util.Scanner;

import static java.lang.System.exit;

public class Date {
    public int day,month,year;
    int flag;
    Date()
    {
        day=22;
        month=11;
        year=1996;
    }
    void dateDis(int d,int m,int y)
    {
        //try{
            if(d>0 && d<=31)
                day=d;
            else {

                System.out.println("invalid dd format");
                DateEntry();
            }
            if(m>0 && m<=12)
        month=m;
        else {

                System.out.println("invalid mm format");
                DateEntry();
            }
        if(y>0 && y>999 && y<10000)
        year=y;
        else {
            System.out.println("invalid year format");
            DateEntry();
        }
    }

  void nextDate(int d,int m,int y,int n) {
      if (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10) {
       if(d<=31) {
           day = d + n;
           if (day < 31) {
               day = day;
               month = m;
               year = y;
           }//day = d + n;
           else if (day == 31) {
               day = day;
               month = m;
               year = y;
           } else {
               day = day - 31;
               month = m + 1;
               year = y;
           }
       }
       else
           System.out.println("invalid date");

      } else if (m == 4 || m == 6 || m == 9 || m == 11) {
         if(d<=30) {
             day = d + n;
             if (day <= 30) {
                 day = day;
                 month = m;
                 year = y;
             } else {
                 month = m + 1;
                 day = day - 30;
                 year = y;
             }
         }
         else
             System.out.println("invalid date");
      }
      else if (m == 12) {
          day=d+n;
          if(day<=31)
          {
              day=day;
              month=m;
              year=y;
          }

          else
          {
             day=day-31;
             month=1;
             year=y+1;
          }
      }
      else {
          if (m == 2) {

              if (((y % 400 == 0) && (y % 100 == 0)) || ((y % 4 == 0) && (y % 100 != 0))) {
                  day=d+n;
                  if (day <=28) {
                      month = m;
                      year = y;
                      day = day;
                  }

//else if(day==28)
                  else if (day == 29) {
                    month=2;
                    year=y;
                    day=day;
                      }

                  else if(day>29)
                  {
                      day=day-29;
                      month=3;
                      year=y;
                  }
                      else
                      System.out.println("invalid date");
              }
              else
              {
                  //non leap
                 if(d<=28)
                 {
                    day=d+n;
                    if(day>28)
                    {
                        day=day-28;
                        month=3;
                        year=y;
                    }
                    else if(day==28)

                    {
                        day=day;
                        month=m;
                        year=y;
                    }
                    else
                    {

                    }
                 }
                 else
                     System.out.println("invalid date");
              }

          }
      }}
    void dateDisplay()
    {
        System.out.println("Date is : "+day+"/"+month+"/"+year);
    }

    //System.out.println("enter the day dd format");
    public static void DateEntry()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("enter the day dd format");
        int d = in.nextInt();
        System.out.println("enter the month mm format ");
        int  m = in.nextInt();
        System.out.println("enter the year yyyy format");
        int y = in.nextInt();

        Date d2 = new Date();

        d2.dateDis(d, m, y);
        // if (flag != 0) {
        d2.dateDisplay();
        System.out.println("enter the increment for next date");
        int n = in.nextInt();
        d2.nextDate(d, m, y, n);
        d2.dateDisplay();
        exit(0);

    }
    public static void main(String[] args) {
        Date d1 = new Date();
        d1.dateDisplay();
        DateEntry();

        }
    }
