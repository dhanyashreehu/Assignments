package books;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Book1 {
    int n,i;
   // Book1 b1 = new Book1();
   Book b[] = new Book[100];
    public void Create_book(int n) {


        for (i = 0; i < n; i++) {
            b[i] = new Book();
            System.out.println("enter the name of book");
            Scanner scn = new Scanner(System.in);
            String bt = scn.nextLine();
            b[i].setBook_title(bt);
            System.out.println("enter the price of book");
            //Scanner scn1 = new Scanner(System.in);
            try {
            double bp = scn.nextDouble();
                         if ((bp >0.00)) {
                    b[i].setBook_price(bp);
                } else
                    throw new Exception();
            } catch (Exception e) {
               i--;
               System.out.println("invalid price..");
               continue;
            }
        }
    }
   public void Show_book(int n) {
        // String bukt=getBook_title();
        System.out.println("book description" + "-------->" + "book price");
              for(i=0;i<n;i++) {
                  String bt = b[i].getBook_title();
                  Double bp = b[i].getBook_price();
                  try {
                      if (bp != null)
                          System.out.println(bt + "--------->" + "Rs." + bp);
                  }
                  catch(NullPointerException e)
                  {
                      continue;
                  }
              }
    }

    public static void main(String[] args) {
int n;
      Book1 buk=new Book1();

      System.out.println("enter the number of books to be created");
        Scanner scn = new Scanner(System.in);
        n = scn.nextInt();

      buk.Create_book(n);
      buk.Show_book(n);

       /* //      Book b[] = new Book[n];
//        Book1 b1 = new Book1();
        //Book b[] = new Book[n];
        for (i = 0; i < n; i++) {
            b[i] = new Book();

            // Book1 b1=new Book();
            b[i].Create_book();
            b[i].Show_book();
            // b[i].setBook_title(bt);
            b[i].getBook_price();
        }*/

    }
}