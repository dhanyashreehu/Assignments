package books;
import java.util.Scanner;

public class Book {
    private String Book_title;
    private Double Book_price;

    public String getBook_title() {
        return Book_title;
    }

    public void setBook_title(String book_title) {
        Book_title = book_title;
    }

    public Double getBook_price() {
        return Book_price;
    }

    public void setBook_price(Double book_price) {
        Book_price = book_price;
    }



     }

