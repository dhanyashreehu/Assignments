package prgm5;

import prgm2.Compartment;

public class Car  {
    public int speed,gear;

    Car() {

    }

    public void drive()
    {
        speed=100;
        gear=5;
    }
    public void display()
    {
        System.out.println("the speed and number of gears are "+speed+" "+gear);
    }
}
