package prgm5;

public class SportsCar extends Car {
public void AirBaloonType()
{
    drive();
}

    @Override
    public void display() {
        super.display();
System.out.println(" in air balooon type");
    }


    public static void main(String[] args)
    {
        Car c=new SportsCar();
        ((SportsCar) c).AirBaloonType();
        c.display();
    }
}

