package prgm2;

public class General extends Compartment{
   public void notice()
    {
        System.out.println("its a general compartment");
    }
}
