package prgm2;

public class luggage extends Compartment {
   public void notice()
    {
        System.out.println("its a luggage compartment");
    }
}
