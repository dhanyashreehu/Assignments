package prgm2;

public class FClass extends Compartment {
    public void notice()
    {
        System.out.println("its a first class compartment");
    }
}
