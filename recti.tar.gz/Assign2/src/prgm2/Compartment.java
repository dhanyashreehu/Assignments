package prgm2;

public abstract class Compartment {
    public abstract void notice();
    public Compartment()
    {
        System.out.println("constructor in compartment class");
    }
}
