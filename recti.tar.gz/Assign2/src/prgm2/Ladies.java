package prgm2;

public class Ladies extends Compartment{
  public void notice()
    {
        System.out.println("its a ladies compartment");
    }
}
