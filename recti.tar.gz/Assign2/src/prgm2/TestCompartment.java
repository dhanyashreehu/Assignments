package prgm2;
import java.util.Random;
public class TestCompartment {
    public static void main(String[] args){

        Compartment comp[]=new Compartment[10];
      //comp[10]=new Compartment();
     //  Compartment * ptr;
//comp[] *ptr;
        //comp[0]=new Ladies();
        Random rand = new Random();

        int  n = rand.nextInt(4) + 1;
        /* for(int i=0;i<n;i++)
        {
            comp[i]=new FClass();
            comp[i].notice();
        }

        */
        System.out.println("the compartment has "+n+" coach");
       if(n==1)
       {

          comp[0]=new FClass();
           comp[0].notice();
       }
       if(n==2)
       {
           comp[0]=new FClass();
           comp[0].notice();
           comp[1]=new Ladies();
           comp[1].notice();
       }
       if(n==3)
       {
           comp[0]=new FClass();
           comp[0].notice();
           comp[1]=new Ladies();
           comp[1].notice();
           comp[2]=new General();
           comp[2].notice();
       }
       if(n==4)
       {
           comp[0]=new FClass();
           comp[0].notice();
           comp[1]=new Ladies();
           comp[1].notice();
           comp[2]=new General();
           comp[2].notice();
           comp[3]=new luggage();
           comp[3].notice();
       }
    }
}
