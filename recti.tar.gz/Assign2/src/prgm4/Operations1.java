package prgm4;

public class Operations1 {
    public int num1, num2;
    public char operator;

   void opera(int n1, int n2, String opr) {
        int res;
        if (opr == "+") {
            res = n1 + n2;
            System.out.println(res);
        } else if (opr == "-") {
            res = n1 - n2;
            System.out.println(res);
        } else if (opr == "*") {
            res = n1 * n2;
            System.out.println(res);
        } else {
            res = n1 / n2;
            System.out.println(res);
        }
    }


    public static void main(int argc, String[] args) {
        // String[] args = new String[10];
      //  System.out.println("enter number1 number2 and operator(+-/*)");
        if (argc == 3) {
            String num1 = args[0];
            int n1 = Integer.parseInt(num1);
            String num2 = args[1];
            int n2 = Integer.parseInt(num2);
            System.out.println("enter the operator");
            String ch = args[2];
            Operations1 op = new Operations1();
           op.opera(n1, n2, ch);
            /*    switch (args[2]) {
                    case "+":{
                        int temp;
                        temp = n1 + n2;
                        System.out.println("Sum=" + temp);}
                    case "-":{
                        int temp;
                        temp = n1 -n2;
                        System.out.println("Sum=" + temp);}
                    case "*":{
                        int temp;
                        temp = n1 * n2;
                        System.out.println("Sum=" + temp);}
                    case "/":{
                        int temp;
                        temp = n1 / n2;
                        System.out.println("Sum=" + temp);}
                }*/

              }
    }
}