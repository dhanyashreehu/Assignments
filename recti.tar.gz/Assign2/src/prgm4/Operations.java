package prgm4;

import java.util.Scanner;

public class Operations {
    public int num1, num2;
    public char operator;

    Operations(int n1, int n2, String opr) {
        int res;
        if(opr=="+") {
            res = n1 + n2;
            System.out.println(res);
        }
        else if(opr=="-") {
            res = n1 - n2;
            System.out.println(res);
        }
        else if(opr=="*") {
            res = n1 * n2;
            System.out.println(res);
        }
        else
        {
            res = n1 / n2;
            System.out.println(res);
        }
    }


    public static void main(String[] arg) {
        int argc = 3;
        String[] args = new String[10];
        Scanner scn = new Scanner(System.in);
        System.out.println("enter number1 number2 and operator(+-/*)");
        args[0] = scn.next();
        args[1] = scn.next();
        args[2] = scn.next();
        //System.out.println("enter number1 number2 and operator(+-/*)");
        String opr = "";
        if (argc == 3) {
            String num1 = args[0];
            int n1 = Integer.parseInt(num1);
            String num2 = args[1];
            int n2 = Integer.parseInt(num2);
            switch (args[2]) {
                case "+":{
                    int temp;
                    temp = n1 + n2;
                    System.out.println("Sum=" + temp);}
                case "-":{
                    int temp;
                    temp = n1 -n2;
                    System.out.println("Sum=" + temp);}
                case "*":{
                    int temp;
                    temp = n1 * n2;
                    System.out.println("Sum=" + temp);}
                case "/":{
                    int temp;
                    temp = n1 / n2;
                    System.out.println("Sum=" + temp);}
            }
        /*System.out.println("enter number 1");
        int n1=scn.nextInt();
        System.out.println("enter number 2");
        int n2=scn.nextInt();
        System.out.println("enter the operator");
        char ch=scn.char();
        Operations op = new Operations(n1, n2, ch);
*/
        }
    }
}

