package prgm3;
import  java.lang.Math;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class TestMedicine {

    public static double getrand(double max, double min)
{
    double x=(int)(Math.random()*((max-min)+1)+min);
    return x;
}

    public  static  void main(String[] args)
    {
        ArrayList<Medicine> al=new ArrayList<Medicine>();

        Scanner scn=new Scanner(System.in);
        Medicine medarr[]=new Medicine[5];
       // medarr[10]=new Medicine();
        for(int i=0;i<5;i++)
        {
            al.add(medarr[i]);
            double n=getrand(3,1);
            System.out.println("generated random number is "+n);
if(n==1)
{
    medarr[i]=new Tablet();
    medarr[i].displayLable();
}
            if(n==2)
            {
                medarr[i]=new Syrup();
                medarr[i].displayLable();
            }
            if(n==3)
            {
                medarr[i]=new Ointment();
                /*System.out.println("enter the company name");
                String name=scn.nextLine();
                med.Cname=name;
                System.out.println("enter the company address");
                String addr=scn.nextLine();
                med.Caddress=addr;*/
                medarr[i].displayLable();
            }
        }
        System.out.println("the array contents are");
        for(int i=0;i<5;i++)
        {
            System.out.println(medarr[i]);
         }
    }
}
