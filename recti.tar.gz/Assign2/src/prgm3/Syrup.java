package prgm3;

public class Syrup extends Medicine{
   public void displayLable()
    {
        super.displayLable();
        System.out.println("syrup class");
        System.out.println("Shake well before use and Close the lid properly");
    }
}
