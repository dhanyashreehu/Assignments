package prgm3;

public class Medicine {
    public String Cname="abc";
    public String Caddress="#123abc";
    Medicine()
    {

      //  System.out.println("medicine cls construtor");
    }
    public String toString() {
        //for(int i=0;i<5;i++)
        return Cname+" "+Caddress;
    }
    public void displayLable()
    {

        System.out.println("the name and address of the company are:"+this.Cname+" and "+this.Caddress);
    }
}
