package prgm3;

public class Ointment extends Medicine {
    public void displayLable()
    {
        super.displayLable();
        System.out.println("ointment class");
        System.out.println("ointments are for external use only");
    }
}
