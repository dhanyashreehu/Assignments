package prgm3;

public class Tablet extends Medicine {
public void displayLable()
{
    super.displayLable();
    System.out.println("Tablet class");

    System.out.println("Always store tablet in a cool and dry place");
}
}
