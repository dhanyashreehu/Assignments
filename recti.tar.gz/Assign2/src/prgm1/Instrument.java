package prgm1;

public abstract class Instrument {
  public int inst[];
   // inst=new int[10];

    public abstract void play();
    Instrument()
    {
        System.out.println("constructor in instrument class");
    }

}
