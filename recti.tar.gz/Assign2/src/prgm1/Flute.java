package prgm1;

public class Flute extends Instrument{
    public void play ()
    {
        System.out.println("Flute is playing toot toot toot");
 // return 0;
    }
}
