package prgm1;

public class Piano extends Instrument{
   public void play()
    {
        System.out.println("piano is playing tan tan tan");
        //return 0;
    }
}
