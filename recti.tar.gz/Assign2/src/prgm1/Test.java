package prgm1;

import java.util.Scanner;

public class Test {
    public static void main(String[] args)
    {//String arr[]=new String[10];
       Instrument arr1[]=new Instrument[10];
        Scanner scan = new Scanner(System.in);

        arr1[0]=new Piano();
        arr1[1]=new Guitar();
        arr1[2]=new Flute();
       for(int i=0;i<3;i++)
        {
            System.out.println(arr1[i] instanceof Instrument);
            System.out.println(i+" index belongs to instance of "+arr1[i]);
            arr1[i].play();
        }
        /*System.out.print("is it a instance of instrument cls: ");
        System.out.println(arr1[0] instanceof Instrument);
        System.out.print("is it a instance of piano cls: ");
        System.out.println(arr1[0] instanceof Piano);
        System.out.print("is it a instance of guitar cls: ");
        System.out.println(arr1[0] instanceof Guitar);
        arr1[0].play(); //  p1.play();
       ;*/
    }

}
